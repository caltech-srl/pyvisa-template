from datetime import datetime
from influxdb_client import InfluxDBClient, Point, WritePrecision
from influxdb_client.client.write_api import SYNCHRONOUS, ASYNCHRONOUS
from assets.connect import Connect
from assets.functions import InfluxClient
from assets.voltage import Voltage
from time import sleep


token, org, bucket = Connect()

IC = InfluxClient(token, org, bucket)

for i in range(1,11):
    time=int(datetime.now().timestamp())
    voltage = Voltage()
    IC.write_data(IC.write_data([f"voltage,tag=3458a value={voltage} {time}"]), write_option=ASYNCHRONOUS)
    sleep(1)
    print(f"{i}, {time}, {voltage}")