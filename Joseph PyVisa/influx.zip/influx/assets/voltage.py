import random

def Voltage():
    # Generate a random voltage value between 0 and 5 volts (adjust the range as needed)
    voltage = round(random.uniform(0, 5), 2)
    return voltage